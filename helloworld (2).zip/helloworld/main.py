import os
from firebase_admin import credentials, firestore, initialize_app
from flask import Flask, request, jsonify
import functions_framework

lab1 = Flask(__name__)
cred = credentials.Certificate('optical-carrier-382612-firebase-adminsdk-64tup-041ad81350.json')
default_app = initialize_app(cred)
db = firestore.client()
students_ref = db.collection('students')
elections_ref = db.collection('elections')


##Getting all students
@lab1.route('/voters', methods=['GET'])
def get_students():
    try:
        student_id = request.args.get('id')
        all_students = [doc.to_dict() for doc in students_ref.stream()]
        return jsonify(all_students), 200
    except Exception as e:
        return f"An Error Occurred: {e}"


###Getting a single student
@lab1.route('/voters/voter', methods=['GET'])
def get_a_student():
    student_id = request.args.get('id')
    if student_id:
        student = students_ref.document(student_id).get()
        return jsonify(student.to_dict()), 200
    return jsonify({'error': 'Record not found'}), 404


###Add a Student to the json file
@lab1.route('/voters', methods=['POST'])
def add_student():
    try:
        student_id = request.json['id']
        students_ref.document(id).set(request.json)
        return jsonify({"success": True}), 200
    except Exception as e:
        return f"An Error Occurred: {e}"


###Update a student record
@lab1.route('/voters', methods=['PUT'])
def update_student():
    try:
        student_id = request.json['id']
        students_ref.document(id).update(request.json)
        return jsonify({"success": True}), 200
    except Exception as e:
        return f"An Error Occurred: {e}"


####Delete a student record
@lab1.route('/voters', methods=['DELETE'])
def delete_student():
    try:
        # Check for ID in URL query
        student_id = request.args.get('id')
        students_ref.document(student_id).delete()
        return jsonify({"success": True}), 200
    except Exception as e:
        return f"An Error Occurred: {e}"


###Getting all elections
@lab1.route('/elections', methods=['GET'])
def get_elections():
    try:
        election_id = request.args.get('id')
        all_elections = [doc.to_dict() for doc in elections_ref.stream()]
        return jsonify(all_elections), 200
    except Exception as e:
        return f"An Error Occurred: {e}"


###Getting a particular election
@lab1.route('/elections/election', methods=['GET'])
def get_an_election():
    election_id = request.args.get('id')
    if election_id:
        election = elections_ref.document(election_id).get()
        return jsonify(election.to_dict()), 200
    return jsonify({'error': 'Record not found'}), 404


###Create an election
@lab1.route('/elections', methods=['POST'])
def create_election():
    try:
        election_id = request.json['id']
        elections_ref.document(id).set(request.json)
        return jsonify({"success": True}), 200
    except Exception as e:
        return f"An Error Occurred: {e}"


###Delete an election
@lab1.route('/elections', methods=['DELETE'])
def delete_election():
    try:
        # Check for ID in URL query
        election_id = request.args.get('id')
        elections_ref.document(election_id).delete()
        return jsonify({"success": True}), 200
    except Exception as e:
        return f"An Error Occurred: {e}"


###Voting in an election
@lab1.route('/vote', methods=['PUT'])
def cast_vote():
    voting_details = request.get_json()
    student_id = voting_details['student_id']
    candidate_id = voting_details['candidate_id']
    election_id = voting_details['election_id']

    ##Election transparency measures
    election_validity = False
    student_validity = False
    candidate_eligibility = False

    if elections_ref.document(election_id).get():
        election_validity = True

    if students_ref.document(student_id).get():
        student_validity = True

    election = elections_ref.document(election_id).get()
    election_details = election.to_dict()

    if int(candidate_id) in election_details['candidates']:
        candidate_eligibility = True

    ##Voting process
    if election_validity == True and student_validity == True and candidate_eligibility == True:
        # Check if student has not yet voted
        voters = elections_ref.document(election_id).get().to_dict()["voters"]
        total_votes = elections_ref.document(election_id).get().to_dict()["totalVotesCast"]
        candidates_votes = elections_ref.document(election_id).get().to_dict()['votes'][candidate_id]

        # Add the new voter ID to the "voters" list
        if student_id not in voters:
            voters.append(student_id)
            # Update the "voters" field in the Firestore document
            elections_ref.document(election_id).update({"voters": voters})

            ##Increment total votes by 1
            total_votes += 1
            elections_ref.document(election_id).update({"totalVotesCast": total_votes})

            ##Increment candidate's votes by 1
            candidates_votes += 1
            elections_ref.document(election_id).update.update({
                f"votes.{candidate_id}": candidates_votes
            })

    return jsonify(elections_ref.document(election_id).get().to_dict())

port = int(os.environ.get('PORT', 8080))
if __name__ == '__main__':
    lab1.run(threaded=True, host='0.0.0.0', port=port)

